<?php
header('location:../');

?>