<?php

function connection(){

	
	$connection=mysqli_connect("localhost","root","","kush_resort");

	return $connection;
}