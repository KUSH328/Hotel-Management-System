-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2022 at 08:04 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kush_resort`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(2, 'admin', 'admin@kushresort.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `phno` varchar(100) NOT NULL,
  `arrival` date NOT NULL,
  `departure` date NOT NULL,
  `adults` varchar(100) NOT NULL,
  `children` varchar(100) NOT NULL,
  `roomtype` varchar(100) NOT NULL,
  `days` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `paymentid` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `bookingdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `name`, `email`, `gender`, `phno`, `arrival`, `departure`, `adults`, `children`, `roomtype`, `days`, `address`, `amount`, `paymentid`, `status`, `bookingdate`) VALUES
(1, 'Jane Wanjiru', 'wanjirujanny23@gmail.com', 'female', '0744752154', '2022-12-11', '2022-12-14', '1', '0', 'economy', '3', 'Adan Abdalla', '9000', 'M-pesa', 'paid', '2022-12-11'),
(2, 'Salama Ali', 'salamaali@gmail.com', 'female', '0744752154', '2022-12-11', '2022-12-14', '1', '0', 'economy', '3', 'Adnan Ndungu', '9000', 'Cash', 'paid', '2022-12-11'),
(3, 'Wesley Kageha', 'kagehawess12@gmail.com', 'male', '0744752154', '2022-12-11', '2022-12-14', '1', '0', 'economy', '3', 'Wilfred Juma', '9000', 'Cash', 'paid', '2018-12-11'),
(4, 'Samuel Mulatya', 'mulatyasam@gmail.com', 'male', '0744752154', '2018-12-11', '2022-12-14', '1', '0', 'standard', '3', 'Ryan Makau', '12000', 'M-pesa', 'paid', '2022-12-11'),
(5, 'Fatuma Kalaa', 'fatumakalaah@gmail.com', 'female', '0744752154', '2022-12-11', '2022-12-14', '1', '0', 'standard', '3', 'Hussein', '12000', 'M-pesa', 'paid', '2022-12-11'),
(6, 'Kenneth Kamau', 'kamauken@gmail.com', 'male', '0744752154', '2022-12-11', '2022-12-14', '1', '0', 'standard', '3', 'Kiarie', '12000', 'Cash', 'paid', '2022-12-11'),
(7, 'Danson Araka', 'arakadan@gmail.com', 'male', '07544752154', '2022-05-15', '2022-05-16', '1', '0', 'economy', '1', 'Ambalava house\r\ol-paramba post', '3000', 'Cash', 'unpaid', '2022-05-15');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `cat` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phno` varchar(100) NOT NULL,
  `msg` varchar(500) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `name`, `email`, `phno`, `msg`, `date`) VALUES
(1, 'ABDUL BASHIR', 'abdulbashir2@gmail.com', '0744752154', 'Hello team, can i make payment using Bitcoin?', '2022-08-24'),
(2, 'KENNETH KAMAU', 'kamauken@gmail.com', '0744752154', '0744752154', '2022-09-10'),
(3, 'WILLIS MIHANGO', 'willymihango@gmail.com', '0744752154', 'I have an orphanage and want to bring them over to Kush Resort for a day. Advise on which date', '2022-09-10'),
(4, 'EZEKIEL KURIA', 'kuriawairoe@gmail.com', '0744752154', 'I have a graduation ceremony on september 26 this year and would like to book the entire resort for 2 days. Kindly reply with price and possibility appproval.', '2022-09-10'),
(5, 'DAVID WAMBA', 'davidwamba@gmail.com', '0744752154', 'I forgot my account password and cant recover it.Please help', '2022-09-10'),
(6, 'BADEH', 'thepythonman@gmail.com', '0744752154', 'How much is the reservation at Kush Resort for a fortnight?', '2022-09-10');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(11) NOT NULL,
  `resort_name` varchar(250) NOT NULL,
  `resort_phno` varchar(250) NOT NULL,
  `resort_email` varchar(250) NOT NULL,
  `resort_fb` varchar(250) NOT NULL,
  `resort_insta` varchar(250) NOT NULL,
  `resort_whatsapp` varchar(250) NOT NULL,
  `resort_address` varchar(250) NOT NULL,
  `resort_about` varchar(2500) NOT NULL,
  `resort_features` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `resort_name`, `resort_phno`, `resort_email`, `resort_fb`, `resort_insta`, `resort_whatsapp`, `resort_address`, `resort_about`, `resort_features`) VALUES
(1, 'Kush Farm Resort', '741748765', 'info@kushfarmresort.com', 'facebook.com/kushresortke', 'instagram.com/kushresortke', 'https://wa.me/254741748765', 'tourist avenue road <br>\r\nKanga Street <br>\r\n673604,  Ngong, Kenya', 'After a busy schedule, everybody needs a break and have time for leisure and recreation. Kush Farm Resort help for  where you can spend time along with your loved ones or family on a holiday trip.\r\n<u><b>Nearest tourist places</b></u>\r\-<b><a href=\"https://www.google.co.in/travel/things-to-do/see-all?g2lb=2502548,2503771,2503781,2504000,4258168,4270442,4284970,4291517,4306835,4515404,4597339,4649665,4703207,4718357,4722900,4723331,4741665,4757164,4758238,4758493,4762561,4779395,4779784,4786153,4786958,4787395,4790928,4794648,4804714&hl=en-KE&gl=ke&cs=1&ssta=1&dest_mid=/m/07lkpm&dest_state_type=sattd&dest_src=ts&q=&poi_mid=/m/09m90j&sa=X&ved=2ahUKEwj1u6n_msP4AhWpgv0HHcosAe0Q69EBKAB6BAgDEAc">Giraffe Centre</a></b>\r\n-   <b><a href=\"https://www.google.co.in/travel/things-to-do/see-all?g2lb=2502548,2503771,2503781,2504000,4258168,4270442,4284970,4291517,4306835,4515404,4597339,4649665,4703207,4718357,4722900,4723331,4741665,4757164,4758238,4758493,4762561,4779395,4779784,4786153,4786958,4787395,4790928,4794648,4804714&hl=en-KE&gl=ke&cs=1&ssta=1&dest_mid=/m/07lkpm&dest_state_type=sattd&dest_src=ts&q=&poi_mid=/m/07przg&sa=X&ved=2ahUKEwj1u6n_msP4AhWpgv0HHcosAe0Q69EBKAF6BAgDEAk">Karen Blixen Museum </a></b>\r\n-   <b><a href=\"https://www.google.co.in/travel/things-to-do/see-all?g2lb=2502548,2503771,2503781,2504000,4258168,4270442,4284970,4291517,4306835,4515404,4597339,4649665,4703207,4718357,4722900,4723331,4741665,4757164,4758238,4758493,4762561,4779395,4779784,4786153,4786958,4787395,4790928,4794648,4804714&hl=en-KE&gl=ke&cs=1&ssta=1&dest_mid=/m/07lkpm&dest_state_type=sattd&dest_src=ts&q=&poi_mid=/m/09m8y2&sa=X&ved=2ahUKEwj1u6n_msP4AhWpgv0HHcosAe0Q69EBKAJ6BAgDEAs">Bomas of Kenya </a></b>\r\n-   <b><a href=\"https://www.google.co.in/travel/things-to-do/see-all?g2lb=2502548,2503771,2503781,2504000,4258168,4270442,4284970,4291517,4306835,4515404,4597339,4649665,4703207,4718357,4722900,4723331,4741665,4757164,4758238,4758493,4762561,4779395,4779784,4786153,4786958,4787395,4790928,4794648,4804714&hl=en-KE&gl=ke&cs=1&ssta=1&dest_mid=/m/07lkpm&dest_state_type=sattd&dest_src=ts&q=&poi_mid=/g/1ptz538z0&sa=X&ved=2ahUKEwj1u6n_msP4AhWpgv0HHcosAe0Q69EBKAN6BAgDEA0">Oloolua Nature Trail</a></b>\r\n-   <b><a href=\"https://www.google.co.in/search?q=Escape+Room+Kenya&stick=H4sIAAAAAAAAAONgFuLUz9U3MM_JLshV4tVP1zc0TDbKtrQwM7TUUsxOttLPyU9OLMnMz4MzrBJLSooSk0HMYgDdIKZUPwAAAA#fpstate=trskp&trifp=kpq%253DEscape%252BRoom%252BKenya%2526skpm%253D/g/11c2k98619%2526t%253Dd">Escape Room Kenya</a></b>\r\n-   <b><a href=\"https://www.google.co.in/travel/things-to-do/see-all?g2lb=2502548,2503771,2503781,2504000,4258168,4270442,4284970,4291517,4306835,4515404,4597339,4649665,4703207,4718357,4722900,4723331,4741665,4757164,4758238,4758493,4762561,4779395,4779784,4786153,4786958,4787395,4790928,4794648,4804714&hl=en-KE&gl=ke&cs=1&ssta=1&dest_mid=/m/07lkpm&dest_state_type=sattd&dest_src=ts&q=&poi_mid=/g/1wt6gk73&sa=X&ved=2ahUKEwj1u6n_msP4AhWpgv0HHcosAe0Q69EBKAR6BAgDEA8">Safari Walk</a></b>\r\n-   <b><a href=\"https://www.google.co.in/travel/things-to-do/see-all?g2lb=2502548,2503771,2503781,2504000,4258168,4270442,4284970,4291517,4306835,4515404,4597339,4649665,4703207,4718357,4722900,4723331,4741665,4757164,4758238,4758493,4762561,4779395,4779784,4786153,4786958,4787395,4790928,4794648,4804714&hl=en-KE&gl=ke&cs=1&ssta=1&dest_mid=/m/07lkpm&dest_state_type=sattd&dest_src=ts&q=&poi_mid=/g/1tsvw7z_&sa=X&ved=2ahUKEwj1u6n_msP4AhWpgv0HHcosAe0Q69EBKAV6BAgDEBE">Animal Orphanage</a></b>\r\n\r\n', 'Kush Farm Resort Team is committed and emphasizes on offering our guests an experience that keeps all ages happy away from the hustle and bustle of the city life, yet not far off from the city making it easily accessible for a quick rejuvenating getaway.\r\nOur team, renowned for their warmth and heartfelt hospitality, look forward to welcoming you to Kush Farm Resort, a home away from home where you can arrive as a guest and leave as a friend.');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(11) NOT NULL,
  `roomname` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `oneline` varchar(100) NOT NULL,
  `comments` varchar(500) NOT NULL,
  `quadity` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `roomname`, `price`, `oneline`, `comments`, `quadity`) VALUES
(1, 'economy', '3000', 'double-bed room', 'Desk, Fan, Heating, Hardwood/Parquet floors, Shower, Hairdryer, Free toiletries, Toilet, Bathroom, Telephone, Flat-screen TV with 220 international channels, Wake-up service, Free WiFi is available in all rooms. Access to common kitchen on the same floor.', '10'),
(2, 'standard', '4000', 'double-bed room with balcony', 'Desk, Fan , Heating , Wooden / Parquet floor , Hairdryer , Free toiletries , toilet , bathroom, telephone , flat-screen TV with 220 international channels , Wake Up calls,  WI-FI is available in all rooms . Access to common kitchen on the same floor.', '10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
